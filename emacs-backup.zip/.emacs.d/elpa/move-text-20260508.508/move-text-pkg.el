;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "move-text" "20260508.508"
  "Move current line or region with M-up or M-down."
  ()
  :url "https://github.com/emacsfodder/move-text"
  :commit "142890cfb46d9c374113b4b49021a4202033147b"
  :revdesc "142890cfb46d"
  :keywords '("edit")
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
