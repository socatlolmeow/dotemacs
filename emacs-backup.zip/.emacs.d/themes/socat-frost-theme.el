(require 'socat)
(socat-theme 'socat-frost '(:keyword "#7fb4ff" :string "#9fd8c8" :type "#b6c8e0" :function "#8fd0f0" :constant "#c2a8f0" :comment "#5f6b7d"))
