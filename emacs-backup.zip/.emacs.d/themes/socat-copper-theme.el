(require 'socat)
(socat-theme 'socat-copper '(:keyword "#d9824a" :string "#c4c98a" :type "#c9a27a" :function "#e8a870" :constant "#e06c5a" :comment "#80695a"))
