(require 'socat)
(socat-theme 'socat-citrus '(:keyword "#d0e060" :string "#f0b860" :type "#90c890" :function "#e8e090" :constant "#f08070" :comment "#70785a"))
