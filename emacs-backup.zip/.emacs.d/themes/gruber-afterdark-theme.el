
;;; gruber-afterdark-theme.el --- A beautiful dark theme -*- lexical-binding: t; -*-

(deftheme gruber-afterdark
  "Deep dark Gruber-inspired theme with vivid, elegant syntax highlighting.")

(let ((bg          "#101014")
      (bg-alt      "#18181e")
      (bg-hl       "#24242d")
      (bg-selection "#343442")
      (fg          "#e8e3d5")
      (fg-dim      "#b0acb9")
      (comment     "#777783")
      (purple      "#dca3ff")
      (cyan        "#80d9d0")
      (green       "#a8d5a2")
      (yellow      "#e8c77b")
      (orange      "#e8b477")
      (red         "#f07878")
      (blue        "#8eafff")
      (pink        "#f19ac2"))

  (custom-theme-set-faces
   'gruber-afterdark

   ;; Core
   `(default ((t (:background ,bg :foreground ,fg))))
   `(cursor ((t (:background ,yellow))))
   `(region ((t (:background ,bg-selection))))
   `(highlight ((t (:background ,bg-hl))))
   `(hl-line ((t (:background ,bg-alt))))
   `(fringe ((t (:background ,bg :foreground ,comment))))
   `(vertical-border ((t (:foreground ,bg-hl))))
   `(minibuffer-prompt ((t (:foreground ,cyan :weight bold))))
   `(link ((t (:foreground ,blue :underline t))))
   `(shadow ((t (:foreground ,comment))))
   `(success ((t (:foreground ,green :weight bold))))
   `(warning ((t (:foreground ,yellow :weight bold))))
   `(error ((t (:foreground ,red :weight bold))))

   ;; Syntax highlighting
   `(font-lock-comment-face ((t (:foreground ,comment :slant italic))))
   `(font-lock-comment-delimiter-face ((t (:foreground ,comment))))
   `(font-lock-string-face ((t (:foreground ,green))))
   `(font-lock-doc-face ((t (:foreground ,cyan :slant italic))))
   `(font-lock-keyword-face ((t (:foreground ,purple :weight bold))))
   `(font-lock-builtin-face ((t (:foreground ,pink))))
   `(font-lock-function-name-face ((t (:foreground ,cyan :weight bold))))
   `(font-lock-variable-name-face ((t (:foreground ,fg-dim))))
   `(font-lock-type-face ((t (:foreground ,orange))))
   `(font-lock-constant-face ((t (:foreground ,yellow))))
   `(font-lock-number-face ((t (:foreground ,orange))))
   `(font-lock-warning-face ((t (:foreground ,red :weight bold))))
   `(font-lock-preprocessor-face ((t (:foreground ,pink))))

   ;; Parentheses and matching
   `(show-paren-match ((t (:background ,bg-selection
                              :foreground ,yellow :weight bold))))
   `(show-paren-mismatch ((t (:background ,red
                                 :foreground ,bg :weight bold))))
   `(rainbow-delimiters-depth-1-face ((t (:foreground ,cyan))))
   `(rainbow-delimiters-depth-2-face ((t (:foreground ,purple))))
   `(rainbow-delimiters-depth-3-face ((t (:foreground ,yellow))))
   `(rainbow-delimiters-depth-4-face ((t (:foreground ,green))))
   `(rainbow-delimiters-depth-5-face ((t (:foreground ,pink))))
   `(rainbow-delimiters-depth-6-face ((t (:foreground ,blue))))
   `(rainbow-delimiters-unmatched-face ((t (:foreground ,red :weight bold))))

   ;; Line numbers
   `(line-number ((t (:foreground "#555560" :background ,bg))))
   `(line-number-current-line ((t (:foreground ,yellow
                                       :background ,bg-alt :weight bold))))

   ;; Mode line
   `(mode-line ((t (:background ,bg-hl :foreground ,fg
                       :box (:line-width 1 :color ,bg-hl)))))
   `(mode-line-inactive ((t (:background ,bg-alt
                                :foreground ,comment
                                :box (:line-width 1 :color ,bg-alt)))))
   `(mode-line-buffer-id ((t (:foreground ,cyan :weight bold))))

   ;; Search
   `(isearch ((t (:background ,yellow :foreground ,bg :weight bold))))
   `(lazy-highlight ((t (:background ,bg-selection
                            :foreground ,yellow))))
   `(match ((t (:background ,bg-selection :foreground ,green))))

   ;; Completion
   `(completions-common-part ((t (:foreground ,cyan :weight bold))))
   `(completions-first-difference ((t (:foreground ,yellow :weight bold))))
   `(company-tooltip ((t (:background ,bg-alt :foreground ,fg))))
   `(company-tooltip-selection ((t (:background ,bg-selection
                                       :foreground ,cyan))))
   `(company-tooltip-common ((t (:foreground ,yellow :weight bold))))
   `(company-scrollbar-bg ((t (:background ,bg-hl))))
   `(company-scrollbar-fg ((t (:background ,comment))))

   ;; Org mode
   `(org-level-1 ((t (:foreground ,cyan :weight bold :height 1.3))))
   `(org-level-2 ((t (:foreground ,purple :weight bold :height 1.15))))
   `(org-level-3 ((t (:foreground ,yellow :weight bold))))
   `(org-level-4 ((t (:foreground ,green))))
   `(org-level-5 ((t (:foreground ,pink))))
   `(org-block ((t (:background ,bg-alt :foreground ,fg))))
   `(org-block-begin-line ((t (:foreground ,comment :slant italic))))
   `(org-block-end-line ((t (:foreground ,comment :slant italic))))
   `(org-code ((t (:foreground ,green))))
   `(org-verbatim ((t (:foreground ,orange))))
   `(org-link ((t (:foreground ,blue :underline t))))
   `(org-todo ((t (:foreground ,red :weight bold))))
   `(org-done ((t (:foreground ,green :weight bold))))
   `(org-date ((t (:foreground ,purple :underline t))))

   ;; Markdown
   `(markdown-header-face-1 ((t (:foreground ,cyan :weight bold :height 1.3))))
   `(markdown-header-face-2 ((t (:foreground ,purple :weight bold :height 1.2))))
   `(markdown-header-face-3 ((t (:foreground ,yellow :weight bold))))
   `(markdown-code-face ((t (:background ,bg-alt :foreground ,green))))
   `(markdown-inline-code-face ((t (:foreground ,green))))
   `(markdown-link-face ((t (:foreground ,blue :underline t))))
   `(markdown-bold-face ((t (:foreground ,orange :weight bold))))
   `(markdown-italic-face ((t (:foreground ,pink :slant italic))))

   ;; Diff
   `(diff-added ((t (:background "#192b24" :foreground ,green))))
   `(diff-removed ((t (:background "#302022" :foreground ,red))))
   `(diff-changed ((t (:background "#292719" :foreground ,yellow))))
   `(diff-header ((t (:background ,bg-hl :foreground ,cyan))))
   `(diff-file-header ((t (:background ,bg-hl :foreground ,purple :weight bold))))

   ;; Magit
   `(magit-branch-local ((t (:foreground ,cyan :weight bold))))
   `(magit-branch-remote ((t (:foreground ,green :weight bold))))
   `(magit-diff-added ((t (:background "#192b24" :foreground ,green))))
   `(magit-diff-removed ((t (:background "#302022" :foreground ,red))))
   `(magit-hash ((t (:foreground ,orange))))
   `(magit-section-heading ((t (:foreground ,yellow :weight bold))))

   ;; Whitespace
   `(trailing-whitespace ((t (:background ,red))))
   `(whitespace-space ((t (:foreground "#33333d"))))
   `(whitespace-tab ((t (:foreground "#33333d"))))
   `(whitespace-line ((t (:background "#292027"))))))

(provide-theme 'gruber-afterdark)

;;; gruber-afterdark-theme.el ends here
