(require 'socat)
(socat-theme 'socat-dusk '(:keyword "#c792ea" :string "#f2c27e" :type "#8ab4f8" :function "#e6a0c4" :constant "#ff9e80" :comment "#6f6a85"))
