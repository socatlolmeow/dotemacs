(require 'socat)
(socat-theme 'socat-mint '(:keyword "#5fd7a7" :string "#e8d88a" :type "#8fc8b8" :function "#8fe8d0" :constant "#f0a090" :comment "#5a7a70"))
