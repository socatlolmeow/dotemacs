(require 'socat)
(socat-theme 'socat-slate '(:keyword "#9db4d0" :string "#b8d0a0" :type "#a0b0c0" :function "#c8d8ea" :constant "#d8b090" :comment "#606a75"))
