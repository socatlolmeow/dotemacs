(require 'socat)
(socat-theme 'socat-plum '(:keyword "#d98ac4" :string "#b0d98a" :type "#b8a0d8" :function "#e8a8d8" :constant "#f0a878" :comment "#75627a"))
