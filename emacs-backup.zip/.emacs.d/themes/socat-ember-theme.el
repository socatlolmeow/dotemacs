(require 'socat)
(socat-theme 'socat-ember '(:keyword "#ff8c42" :string "#a8cc8c" :type "#d6a86c" :function "#e8b98a" :constant "#ff6b5e" :comment "#7d6a5a"))
