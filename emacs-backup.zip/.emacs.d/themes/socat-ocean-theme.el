(require 'socat)
(socat-theme 'socat-ocean '(:keyword "#4fc3d9" :string "#8fd9a8" :type "#7aa8d0" :function "#5fb8e8" :constant "#f0b27a" :comment "#5a7080"))
