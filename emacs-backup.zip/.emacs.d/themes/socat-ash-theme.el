(require 'socat)
(socat-theme 'socat-ash '(:keyword "#c8c8d8" :string "#a0b890" :type "#a8a8b8" :function "#e0e0f0" :constant "#d0a880" :comment "#666670"))
