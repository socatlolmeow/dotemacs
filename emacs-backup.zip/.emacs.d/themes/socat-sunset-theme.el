(require 'socat)
(socat-theme 'socat-sunset '(:keyword "#ff6f61" :string "#ffc66d" :type "#f2a65a" :function "#ff9f68" :constant "#e86a92" :comment "#7d6560"))
