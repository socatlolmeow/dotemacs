(require 'socat)
(socat-theme 'socat-lavender '(:keyword "#b4a0f0" :string "#a8d8b0" :type "#98b8f0" :function "#d0b8f8" :constant "#f0c0a0" :comment "#686480"))
