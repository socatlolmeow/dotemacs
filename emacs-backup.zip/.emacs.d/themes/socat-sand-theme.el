(require 'socat)
(socat-theme 'socat-sand '(:keyword "#e0b366" :string "#a6c98f" :type "#c9b896" :function "#e8d08a" :constant "#d98e73" :comment "#7a7060"))
