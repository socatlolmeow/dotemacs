(require 'socat)
(socat-theme 'socat-moss '(:keyword "#a3c46a" :string "#d9c27a" :type "#8fb59a" :function "#c8dc9a" :constant "#e0a070" :comment "#66735a"))
